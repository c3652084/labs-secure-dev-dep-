HOW TO OPEN THIS PROJECT

1. Open Android Studio.
2. Click Open.
3. Select the folder HospitalAppAllLabsStarter.
4. Let Gradle sync.
5. If Android Studio asks to trust the project, click Trust Project.
6. Run RegisterActivity.

WHAT IS INCLUDED
- Lab 1: Patient registration + validation + Room database
- Lab 2: Appointment booking + conflict detection + biometric demo + Retrofit demo
- Lab 3: EHR screen + barcode scan demo
- Lab 4: Encrypted shared preferences + parameterised Room queries + validation

WHAT TO SCREENSHOT
- Registration form and successful save
- Validation errors
- Appointment booking and conflict detection
- Biometric prompt
- EHR save
- Barcode scan
- SecurityUtils.java
- ValidationUtilsTest.java
